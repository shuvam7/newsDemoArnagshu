package main.java.com.stackroute.favouriteservice.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.core.net.SyslogOutputStream;
import io.jsonwebtoken.Jwts;
import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleAlreadyExistsException;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleNotFoundException;
import main.java.com.stackroute.favouriteservice.services.NewsArticleService;
/**
 * @author 729707
 *
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(path="/api/v1/news")
public class NewsArticleController {
	

	private NewsArticleService newsArticleService;

	private ResponseEntity<?> responseEntity;

	@Autowired
	public NewsArticleController(NewsArticleService newsArticleService) {
		this.newsArticleService = newsArticleService;
	}
	
	/**
	 * method to save newsArticle
	 * 
	 * @param newsArticle
	 * return newsArticle object/failure message
	 */
	
	@PostMapping("/news")
	public ResponseEntity<?> saveFavouriteNewsArticle(@RequestBody final NewsArticle newsArticle, final HttpServletRequest request,
			final HttpServletResponse response) {
		final String authHeader = request.getHeader("authorization");
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		try {
			newsArticle.setUserId(userId);
			newsArticleService.saveNewsArticle(newsArticle);
			responseEntity = new ResponseEntity<NewsArticle>(newsArticle, HttpStatus.CREATED);
		} catch (NewsArticleAlreadyExistsException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}",
					HttpStatus.CONFLICT);
		} catch (Exception e) {
			return new ResponseEntity<String>("Internal Server Error.Please Try Again Later.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	/**
	 * method to delete newsArticle
	 * 
	 * @param id
	 * return true/failure message
	 */
	@DeleteMapping("/news/{id}")
	public ResponseEntity<?> deleteFavouriteNewsArticleById(@PathVariable("id") final int id) {
		ResponseEntity<?> responseEntity;
		try {
			newsArticleService.deleteNewsArticleById(id);
			responseEntity = new ResponseEntity<String>("Movie deleted successfully", HttpStatus.OK);
		} catch (NewsArticleNotFoundException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.NOT_FOUND);
		}
		return responseEntity;
		
	}

	/**
	 * method to getting movie list
	 * return Movie/failure message
	 */
	@GetMapping("/news")
	public ResponseEntity<?> getAllFavouriteNewsArticlesOfUser(final HttpServletRequest request,
			final HttpServletResponse response) {
		final String authHeader = request.getHeader("authorization");
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		try {
			List<NewsArticle> newsArticles = newsArticleService.getFavouriteNewsArticles(userId);
System.out.println("hihi");
			return new ResponseEntity<List<NewsArticle>>(newsArticles, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>("Internal Server Error.Please Try Again Later.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



}
