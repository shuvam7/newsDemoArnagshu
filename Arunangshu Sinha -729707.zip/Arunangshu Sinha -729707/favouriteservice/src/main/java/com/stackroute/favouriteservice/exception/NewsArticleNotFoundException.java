package main.java.com.stackroute.favouriteservice.exception;

/**
 * @author 729707
 *
 */
@SuppressWarnings("serial")
public class NewsArticleNotFoundException extends Exception {

	String message;

	public NewsArticleNotFoundException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "NewsArticleNotFoundException [message=" + message + "]";
	}
}
