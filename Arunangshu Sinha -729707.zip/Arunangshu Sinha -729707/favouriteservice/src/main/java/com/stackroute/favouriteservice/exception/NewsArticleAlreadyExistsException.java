package main.java.com.stackroute.favouriteservice.exception;

/**
 * @author 729707
 *
 */
@SuppressWarnings("serial")
public class NewsArticleAlreadyExistsException extends Exception {

	String message;

	public NewsArticleAlreadyExistsException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "NewsArticleAlreadyExistsException [message=" + message + "]";
	}

}
