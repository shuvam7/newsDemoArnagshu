package main.java.com.stackroute.favouriteservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import main.java.com.stackroute.favouriteservice.domain.NewsArticle;

public interface NewsArticleRepository extends JpaRepository<NewsArticle, Integer> {

	Optional<NewsArticle> findByTitleAndUserId(String title,String userId);
	
	List<NewsArticle> findNewsArticleByUserId(String userId);
}
