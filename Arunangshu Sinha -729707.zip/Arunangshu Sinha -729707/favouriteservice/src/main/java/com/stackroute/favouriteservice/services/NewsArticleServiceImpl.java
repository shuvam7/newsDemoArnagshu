package main.java.com.stackroute.favouriteservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleAlreadyExistsException;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleNotFoundException;
import main.java.com.stackroute.favouriteservice.repository.NewsArticleRepository;

@Service
public class NewsArticleServiceImpl implements NewsArticleService {

	private final transient NewsArticleRepository newsArticleRepository;

	@Autowired
	public NewsArticleServiceImpl(NewsArticleRepository movieRepo) {
		super();
		this.newsArticleRepository = movieRepo;
	}

	@Override
	public boolean saveNewsArticle(NewsArticle newsArticle) throws NewsArticleAlreadyExistsException {
		Optional<NewsArticle> actualNewsArticle = newsArticleRepository.findByTitleAndUserId(newsArticle.getTitle(), newsArticle.getUserId());
		if (actualNewsArticle.isPresent()) {
			System.out.println("it us null");
			throw new NewsArticleAlreadyExistsException("Could not mark the article as favourite, Article already exists");
		}
		newsArticleRepository.save(newsArticle);
		return true;

	}

	@Override
	public boolean deleteNewsArticleById(int id) throws NewsArticleNotFoundException {
		final NewsArticle newsArticle = newsArticleRepository.findById(id).orElse(null);
		if (newsArticle == null) {
			throw new NewsArticleNotFoundException("Could not delete. Article is never marked as favourite");
		}
		newsArticleRepository.deleteById(id);
		return true;

	}

	@Override
	public List<NewsArticle> getFavouriteNewsArticles(String userId) {
		return newsArticleRepository.findNewsArticleByUserId(userId);
	}

	

}
