package main.java.com.stackroute.favouriteservice.services;

import java.util.List;

import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleAlreadyExistsException;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleNotFoundException;

public interface NewsArticleService {
	boolean saveNewsArticle(NewsArticle movie) throws NewsArticleAlreadyExistsException;

	boolean deleteNewsArticleById(int id) throws NewsArticleNotFoundException;

	List<NewsArticle> getFavouriteNewsArticles(String userId);


}
