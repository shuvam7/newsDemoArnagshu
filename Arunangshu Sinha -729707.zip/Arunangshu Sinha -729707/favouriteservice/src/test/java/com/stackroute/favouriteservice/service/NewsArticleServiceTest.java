package test.java.com.stackroute.favouriteservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;



import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleAlreadyExistsException;
import main.java.com.stackroute.favouriteservice.exception.NewsArticleNotFoundException;
import main.java.com.stackroute.favouriteservice.repository.NewsArticleRepository;
import main.java.com.stackroute.favouriteservice.services.NewsArticleServiceImpl;

public class NewsArticleServiceTest {
	@Mock
	private transient NewsArticleRepository newsArticleRepository;

	private transient NewsArticle newsArticle;

	@InjectMocks
	private transient NewsArticleServiceImpl newsArticleServiceImpl;

	transient Optional<NewsArticle> options;

	@Before
	public void setupMock() {
		MockitoAnnotations.initMocks(this);
		newsArticle = new NewsArticle("nantu123", "Title Testing 1", "description of testing", "content",
				"2015-03-23", "www.abc.com", "www.url.com", "www.image.com");
		options = Optional.of(newsArticle);
	}

	

	@Test
	public void testSavingArticleSuccess() throws NewsArticleAlreadyExistsException {
		when(newsArticleRepository.findByTitleAndUserId(newsArticle.getTitle(), newsArticle.getUserId())).thenReturn(Optional.ofNullable(null));
		when(newsArticleRepository.save(newsArticle)).thenReturn(newsArticle);
		final boolean flag = newsArticleServiceImpl.saveNewsArticle(newsArticle);
		assertTrue("saving movie failed", flag);
		verify(newsArticleRepository, times(1)).save(newsArticle);
	}

	@Test(expected = NewsArticleAlreadyExistsException.class)
	public void testSaveNewsArticleFailure() throws NewsArticleAlreadyExistsException {
		when(newsArticleRepository.findByTitleAndUserId( "Title Testing 1","nantu123")).thenReturn(options);
		when(newsArticleRepository.save(newsArticle)).thenReturn(newsArticle);
		final boolean flag = newsArticleServiceImpl.saveNewsArticle(newsArticle);
		assertTrue("saving article failed", flag);
		verify(newsArticleRepository, times(1)).findByTitleAndUserId(newsArticle.getTitle(), newsArticle.getUserId());
	}

	@Test
	public void testdeleteFavouriteArticleById() throws NewsArticleNotFoundException {
		
		when(newsArticleRepository.findById(newsArticle.getId())).thenReturn(options);
		final boolean flag = newsArticleServiceImpl.deleteNewsArticleById(newsArticle.getId());
		assertEquals(true, flag);
		verify(newsArticleRepository, times(1)).deleteById(newsArticle.getId());
		verify(newsArticleRepository, times(1)).findById(newsArticle.getId());
	}
	
	
	@Test(expected = NewsArticleNotFoundException.class)
	public void testForDeleteFavouriteArticleFailure() throws NewsArticleNotFoundException {
		when(newsArticleRepository.findById(1)).thenReturn(Optional.ofNullable(null));
		assertEquals(new NewsArticleNotFoundException(""), newsArticleServiceImpl.deleteNewsArticleById(newsArticle.getId()));
	}
	

	@Test
	public void testGettingUserMarkedFavouriteArticles() throws NewsArticleNotFoundException {
		final List<NewsArticle> newsArticleslist = new ArrayList<>();
		newsArticleslist.add(newsArticle);
		when(newsArticleRepository.findNewsArticleByUserId(newsArticle.getUserId())).thenReturn(newsArticleslist);
		final List<NewsArticle> newArticle = newsArticleServiceImpl.getFavouriteNewsArticles("nantu123");
		assertEquals(newsArticleslist, newArticle);
		verify(newsArticleRepository, times(1)).findNewsArticleByUserId("nantu123");
	}
	


}
