package test.java.com.stackroute.favouriteservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;

import main.java.com.stackroute.favouriteservice.FavouriteServiceApplication;
import main.java.com.stackroute.favouriteservice.controller.NewsArticleController;
import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.services.NewsArticleService;
@ContextConfiguration(classes=FavouriteServiceApplication.class)
@RunWith(SpringRunner.class)
@WebMvcTest(NewsArticleController.class)
    
	public class NewsArticleControllerTest {

		@Autowired
		private transient MockMvc mvc;

		@MockBean
		private transient NewsArticleService newsArticleService;

		private transient NewsArticle newsArticle;

		@InjectMocks
		private NewsArticleController controller;

		static List<NewsArticle> newsArticles;

		@Before
		public void setUp() {
			MockitoAnnotations.initMocks(this);

			mvc = MockMvcBuilders.standaloneSetup(controller).build();
			newsArticles = new ArrayList<>();
			newsArticle = new NewsArticle("nantu123", "Title Testing MockMVc", "description of testing",
					"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com");
			newsArticles.add(newsArticle);
			newsArticle = new NewsArticle("nantu123", "Title Testing MockMVc", "description of testing",
					"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com");
			newsArticles.add(newsArticle);
		}
		
		@Test
		public void testMarkingNewArticleAsFavourite() throws Exception {
			String token = "eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJuYW50dTEyMyIsImlhdCI6MTU1MzA4NjEyNH0.YT-HlGhWRPuDtRMoVJ86Qwku51bSy2VcjBG-QaIpi78JQa0DM4rFD_fBU8rn4EH3";
			
			when(newsArticleService.saveNewsArticle(newsArticle)).thenReturn(true);
			mvc.perform(post("/api/v1/news/news").header("authorization", "Bearer " + token).
					contentType(MediaType.APPLICATION_JSON).content(jsonToString(newsArticle)))
			.andExpect(status().isCreated());
			verify(newsArticleService, times(1)).saveNewsArticle(Mockito.any(NewsArticle.class));
			verifyNoMoreInteractions(newsArticleService);
		}
		
		@Test
		public void testDeletedMarkedArticleById() throws Exception {
			
			when(newsArticleService.deleteNewsArticleById(newsArticle.getId())).thenReturn(true);
			mvc.perform(delete("/api/v1/news/news/{id}",newsArticle.getId())).andExpect(status().isOk());
			verify(newsArticleService, times(1)).deleteNewsArticleById(newsArticle.getId());
	          verifyNoMoreInteractions(newsArticleService);
		
			}


		@Test
		public void testGetAllFavouriteArticleOfAUser() throws Exception {
			String token = "eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJuYW50dTEyMyIsImlhdCI6MTU1MzA4NjEyNH0.YT-HlGhWRPuDtRMoVJ86Qwku51bSy2VcjBG-QaIpi78JQa0DM4rFD_fBU8rn4EH3";
		    when(newsArticleService.getFavouriteNewsArticles(("nantu123"))).thenReturn(null);
			mvc.perform(get("/api/v1/news/news/").header("authorization", "Bearer " + token)
					.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
			verify(newsArticleService, times(1)).getFavouriteNewsArticles("nantu123");
			verifyNoMoreInteractions(newsArticleService);
		}


		private String jsonToString(final Object object) {
			String result;
			try {
				final ObjectMapper mapper = new ObjectMapper();
				result = mapper.writeValueAsString(object);
			} catch (JsonProcessingException e) {
				result = "Json processing error";
			}
			return result;
		}

}
