package test.java.com.stackroute.favouriteservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import main.java.com.stackroute.favouriteservice.FavouriteServiceApplication;
@ContextConfiguration(classes=FavouriteServiceApplication.class)
@RunWith(SpringRunner.class)
@SpringBootTest
public class FavouriteServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}

