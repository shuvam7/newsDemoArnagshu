package test.java.com.stackroute.favouriteservice.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.stackroute.favouriteservice.FavouriteServiceApplication;
import main.java.com.stackroute.favouriteservice.domain.NewsArticle;
import main.java.com.stackroute.favouriteservice.repository.NewsArticleRepository;


@ContextConfiguration(classes=FavouriteServiceApplication.class)
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class NewsArticleRepositoryTest {

	@Autowired
	private transient NewsArticleRepository newsArticleRepository;

	@After
	public void tearDown() {

		newsArticleRepository.deleteAllInBatch();

	}

	/**
	 * Test for saving a movie
	 */

	@Test
	public void testForSaveMovie() throws Exception {
		final NewsArticle newsArticle = newsArticleRepository.save(new NewsArticle("kiran123@gmail.com", "Title Testing 1", "description of testing",
				"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com"));
		
		assertThat(newsArticle.getTitle()).isEqualTo("Title Testing 1");

		newsArticleRepository.deleteAllInBatch();
	}

	/**
	 * Test for updating a movie
	 */


	/**
	 * Test for deleting a movie
	 */

	@Test
	public void testForDeletingMovie() throws Exception {
		
		final NewsArticle newsArticle = newsArticleRepository.save(new NewsArticle("kiran123@gmail.com", "Title Testing 1", "description of testing",
				"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com"));
		assertThat(newsArticle.getTitle()).isEqualTo("Title Testing 1");
		newsArticleRepository.delete(newsArticle);
		assertEquals(Optional.empty(), newsArticleRepository.findById(1));
		
	}


	/**
	 * Test for getting all movie
	 */

	@Test
	public void testForGetMyMovie() throws Exception {
		final NewsArticle newsArticle1 = newsArticleRepository.save(new NewsArticle("kiran123@gmail.com", "Title Testing 1", "description of testing",
				"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com"));
		newsArticleRepository.save(newsArticle1);
		final NewsArticle newsArticle2 = newsArticleRepository.save(new NewsArticle("kiran123@gmail.com", "Title Testing 2", "description of testing",
				"content", "2015-03-23", "www.abc.com", "www.url.com", "www.image.com"));

	   newsArticleRepository.save(newsArticle2);
		final List<NewsArticle> movieList = newsArticleRepository.findAll();
		assertThat(movieList.size()>0);
		newsArticleRepository.deleteAllInBatch();
		
	}
}