import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule,MatButton} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import { MatDialogModule} from '@angular/material/dialog';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { NewsRoutingModule } from './modules/news/news-routing.module'
import { NewsModule } from './modules/news/news.module';
import { NavbarComponent } from './navbar/navbar.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatSidenavModule, MatListModule } from '@angular/material';
import {MatTooltipModule} from '@angular/material/tooltip'
import { AuthGuardService } from './auth-guard.service';



const appRoutes: Routes=[
  {
    path: '',
    redirectTo: '/register',
    pathMatch: 'full'

  }
]
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,NewsModule,
    AppRoutingModule,NewsRoutingModule,AuthenticationModule,MatInputModule,FormsModule,MatDialogModule,MatIconModule,
   MatButtonModule,MatTooltipModule,MatToolbarModule,BrowserAnimationsModule,ReactiveFormsModule,RouterModule.forRoot(appRoutes), LayoutModule, MatSidenavModule, MatListModule
  ],
  providers: [AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
