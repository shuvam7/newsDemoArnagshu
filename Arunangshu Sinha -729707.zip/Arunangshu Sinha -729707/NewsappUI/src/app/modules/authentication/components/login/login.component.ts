import { Component, OnInit } from '@angular/core';
import { User } from '../../user';
import { AuthenticationService } from '../../authentication.service';
import { Router } from '@angular/router';
import { FormGroup,Validators,  FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  registerForm: FormGroup;


  hide = true;
  user:User;

  constructor(private authService: AuthenticationService,private snackbar: MatSnackBar, private router: Router,private formBuilder: FormBuilder) { }



  ngOnInit() {

   this.registerForm = this.formBuilder.group({
      "userId":new FormControl('',[ Validators.required]),
      "password":new FormControl('',[ Validators.required]),
    
      })
  }
  loginUser() {
    if (this.registerForm.invalid) {
      return;
    };
    this.user = new User(this.registerForm.get('userId').value,this.registerForm.get('password').value,null, null);
   console.log(this.registerForm.get('userId').value);
  
    console.log("Login user", this.user);
    this.authService.loginUser(this.user).subscribe(data => {
    let message=JSON.stringify(data.message)
      console.log("Login successful",message);
      if(data['token']) {
        this.authService.setToken(data['token']);
        this.router.navigate(['/news']);
      }},
      
   
    (error) =>{
      this.snackbar.open('UserId Or Password Wrong', '', {
        duration: 3000,
        verticalPosition:'top'
    });
    this.router.navigate(['/register']);

    }); }
  }


