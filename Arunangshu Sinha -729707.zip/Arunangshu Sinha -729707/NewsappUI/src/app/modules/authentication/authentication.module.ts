import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { AuthenticationService } from './authentication.service';
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { FormsModule } from '@angular/forms';
import {MatButtonModule,MatButton} from '@angular/material/button';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MatInputModule, MatDialogModule,MatIcon,MatFormFieldModule } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';
import { Routes, RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';


@NgModule({
  declarations: [RegisterComponent, LoginComponent],
  imports: [
    CommonModule,FormsModule,MatButtonModule,ReactiveFormsModule,
    MatSnackBarModule,MatInputModule,MatDialogModule,MatIconModule,MatFormFieldModule,RouterModule,HttpClientModule
  ],
  providers:[AuthenticationService],
  exports: [
    AuthenticationRoutingModule
  ]

})
export class AuthenticationModule { }
