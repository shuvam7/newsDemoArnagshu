import { Component, OnInit } from '@angular/core';
import { NewsArticle } from '../../NewsArticle';
import { NewsService } from '../../news.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-news-favourite',
  templateUrl: './news-favourite.component.html',
  styleUrls: ['./news-favourite.component.css']
})
export class NewsFavouriteComponent implements OnInit {
  mArticles:Array<NewsArticle>;
  constructor(private newsService:NewsService,private snackbar: MatSnackBar) { }

  ngOnInit() {

    this.newsService.getFavouriteArticle().subscribe(data=>{
      
      this.mArticles=data;

      if(this.mArticles.length==0){
        this.snackbar.open('No Favourite News', '', {
          duration: 3000,
            verticalPosition:'top'
        });
      }

  });

  


}

deleteFromFavourite(article) {

  for (var i = 0; i < this.mArticles.length; i++) {
    if (this.mArticles[i].id === article.id) {
      this.mArticles.splice(i, 1);
    }
  }

  
  this.newsService.deleteFromFavourite(article).subscribe((res) => {

    this.snackbar.open('news deleted from watchlist', '', {
      duration: 3000,
        verticalPosition:'top'
    });
    if(this.mArticles.length==0){
      this.snackbar.open('No Favourite News', '', {
        duration: 3000,
          verticalPosition:'top'
      });
    }
  });
}

}