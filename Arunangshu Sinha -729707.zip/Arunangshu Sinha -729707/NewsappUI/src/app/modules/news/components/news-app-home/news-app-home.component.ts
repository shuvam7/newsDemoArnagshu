import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../news.service';
import { MatSnackBar } from '@angular/material';
import { NewsArticle } from '../../NewsArticle';


@Component({
  selector: 'app-news-app-home',
  templateUrl: './news-app-home.component.html',
  styleUrls: ['./news-app-home.component.css']
})
export class NewsAppHomeComponent implements OnInit {
  mArticles:Array<any>;
  favouriteNews:NewsArticle;
  news:String[];
  constructor(private newsService:NewsService,private snackbar: MatSnackBar) { }

  ngOnInit() {
    this.newsService.initArticles().subscribe(data=>{this.mArticles=data['articles'];

    });

    
  }
  AddToFavorite(article){
    this.favouriteNews=article;
    this.favouriteNews.sourceWebsiteName=article.source.name,
   
    
    this.newsService.addToFavourite(this.favouriteNews).subscribe((article) => {
    
      this.snackbar.open('news added to watchlist', '', {
        duration: 3000,
        verticalPosition:'top'
      });
    },
    (error) =>{
      this.snackbar.open('news already added to favourite', '', {
        duration: 3000,
        verticalPosition:'top'
    });


    });
  }
  onEnter(searchKey) {
    if(searchKey==null ||searchKey.length==0){
      this.snackbar.open('Search a valid Data', '', {
        duration: 3000,
        verticalPosition:'top'
    });
    }
    this.newsService.searchNews(searchKey).subscribe(data => {
      this.news=data['articles'];
      console.log(this.news);
      if(this.news.length==0){
        this.snackbar.open('No Data Found', '', {
          duration: 3000,
          verticalPosition:'top'
      });
  
      }
      else{
        
      this.mArticles = data['articles'];
    }
  });
}
}