import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsAppHomeComponent } from './components/news-app-home/news-app-home.component';
import { NewsFavouriteComponent } from './components/news-favourite/news-favourite.component';
import {MatButtonModule,MatButton} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MatInputModule, MatDialogModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import {MatCardModule} from '@angular/material/card';
import { NewsRoutingModule} from './news-routing.module';
import { NewsService } from './news.service';
import { TokenInterceptorService } from './token-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

@NgModule({
  declarations: [NewsAppHomeComponent, NewsFavouriteComponent],
  imports: [
    CommonModule,MatButtonModule,MatIconModule,MatSnackBarModule,MatInputModule,MatDialogModule,FormsModule,MatCardModule,NewsRoutingModule
  ], providers:[NewsService, {
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptorService,
    multi: true
  }]
})
export class NewsModule { }
