export class NewsArticle{
    id:Number;
    userId:string; 
    title:string; 
    description:string;
    publishedAt:string;        
    content:string; 
    sourceWebsiteName:string;
    url:string;
    urlToImage:string
}