import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{RouterModule, Routes} from '@angular/router';
import { NewsAppHomeComponent } from './components/news-app-home/news-app-home.component';
import { NewsFavouriteComponent } from './components/news-favourite/news-favourite.component';
import { AuthGuardService } from 'src/app/auth-guard.service';

const newsRoutes: Routes=[
  {path:'news',
  children:[
    {
      path:'',
      redirectTo:'/news/home',
     pathMatch:'full',
     canActivate: [AuthGuardService]
   
    },{
      path:'home',
      component:NewsAppHomeComponent,
      canActivate: [AuthGuardService]
     
    },
    {
      path:'favourite',
      component:NewsFavouriteComponent,
      canActivate: [AuthGuardService]
     
    },
  
  
  ]}];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
      
      RouterModule.forChild(newsRoutes)
    ],
    exports:[
      RouterModule
  
    ]
 
})
export class NewsRoutingModule { }
