import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import { NewsArticle } from './NewsArticle';

@Injectable({
  providedIn: 'root'
})
export class NewsService {

  api_key = 'b9e4bdf9110b41baad1cfe567547ad53';
  baseUrl:string ="http://localhost:7253/api/v1/news/news";

  constructor(private http:HttpClient) { }


  initArticles(){
    
    return this.http.get('https://newsapi.org/v2/everything?sources=cnn&apiKey='+this.api_key+'&pageSize=30&sortBy=popularity');
   
  }

  getArticlesByID(source: String){
    return this.http.get('https://newsapi.org/v2/everything?' +
    'q='+source+
  
    '&apiKey='+this.api_key+'&pageSize=30&sortBy=relevancy' );
   }
   addToFavourite(article){
 
     return this.http.post(this.baseUrl,article,{responseType: 'text'});
   }

   getFavouriteArticle(){
    return this.http.get<Array<NewsArticle>>(this.baseUrl);
  
   }

   deleteFromFavourite(article) {
     console.log(article.id);
    return this.http.delete(this.baseUrl+'/' + article.id,{responseType: 'text'});
  }

  searchNews(searchTopic) {
    return this.http.get('https://newsapi.org/v2/everything?q=' + searchTopic + '&apiKey=' + this.api_key);
  }
}
